% Authors:
% Stefan M. Karlsson AND Josef Bigun 

function edgeIm = DoEdgeStrength(dx,dy)

%%% TODO make edgeIm equal to the gradient magnitude,
edgeIm = zeros(size(dx)); %this line should not be zeros
    