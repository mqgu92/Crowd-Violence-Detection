VideoLocation = ''
%strcat(fullfile(VideoList{1,2:3}),'.avi')
VideoDisplay( VIDEO_DIR )