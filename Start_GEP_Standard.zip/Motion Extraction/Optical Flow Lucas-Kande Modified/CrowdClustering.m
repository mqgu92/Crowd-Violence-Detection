function [ output_args ] = CrowdClustering( input_args )
%CROWDCLUSTERING Summary of this function goes here
%   Detailed explanation goes here


end

