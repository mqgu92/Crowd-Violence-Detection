function [ output_args ] = ExtractGLCM( input_args )
%EXTRACTGLCM Summary of this function goes here
%   Detailed explanation goes here


end

