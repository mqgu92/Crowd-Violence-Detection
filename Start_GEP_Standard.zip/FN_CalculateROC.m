function [ output_args ] = FN_CalculateROC( input_args )
%FN_CALCULATEROC Summary of this function goes here
%   Detailed explanation goes here


end

