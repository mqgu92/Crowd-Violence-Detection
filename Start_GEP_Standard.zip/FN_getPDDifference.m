function [ output_args ] = FN_getPDDifference( input_args )
%FN_GETPDDIFFERENCE Summary of this function goes here
%   Detailed explanation goes here


end

