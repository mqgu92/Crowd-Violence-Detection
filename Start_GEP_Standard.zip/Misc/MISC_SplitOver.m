function [ output_args ] = MISC_SplitOver( input_args )
%MISC_SPLITOVER Summary of this function goes here
%   Detailed explanation goes here


end

